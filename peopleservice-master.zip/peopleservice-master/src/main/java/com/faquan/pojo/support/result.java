package com.faquan.pojo.support;

import lombok.Data;

@Data
public class result {
    int flag;
    Object Data;
}
