import json
import urllib3

def lambda_handler(event, context):
    # TODO implement
    '''
    Front end parameters: {ProductId: "dd", PersonId: "ss"}
    need to update frontend to ask for hardcoded values of "number", "price",
    "salesmanId"
    '''
    productId = event['queryStringParameters']["ProductId"]
    productServiceEndpoint = f'https://product-microservice-406302.uc.r.appspot.com/products/{productId}'
    
    # peopleService get by user id
    personId = event['queryStringParameters']["PersonId"]
    personIdEncodedBody = json.dumps({"id": personId})
    headers={'Content-Type': 'application/json'}
    
    peopleServiceEndpoint = 'http://34.132.102.197/peopleAccount'
    
    orderEncodedBody = json.dumps(
        {
            "productId": productId,
            "number": 400,
            "price": 400,
            "clientId": personId,
            "salesmanId": 0
        }
    )
    orderServiceEndpoint = 'http://34.41.220.50:8080/orders'

    
    
    http = urllib3.PoolManager()
    
    productServiceResponse = json.loads(http.request('GET', productServiceEndpoint).data.decode("utf-8"))
    peopleServiceResponse = json.loads(http.request('GET', peopleServiceEndpoint, body=personIdEncodedBody, headers=headers).data.decode("utf-8"))['data']
    
    orderServiceResponse = json.loads(http.request('POST', orderServiceEndpoint, body=orderEncodedBody, headers=headers).data.decode("utf-8"))['data']
    
    http = urllib3.PoolManager()
    
    return {
        'statusCode': 200,
        'body': [productServiceResponse, peopleServiceResponse, orderServiceResponse]
    }
