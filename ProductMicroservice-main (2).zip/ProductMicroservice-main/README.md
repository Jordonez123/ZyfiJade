# ProductMicroservice
```
gcloud init
gcloud app deploy
```
#test
